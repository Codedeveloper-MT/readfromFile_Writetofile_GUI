
 
package comboboxapp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.nio.file.Files.write;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ComboBoc_CheckBox_TextArea_btn extends JFrame{
    
    private JLabel lblFruit;
    private JLabel lblVegitable;
    private JComboBox<String> cmbxFruit;
    private JCheckBox chbxVegitables;
    private JTextArea taDisplay;
    private JButton btnSave;
     private JButton btnDisplay;
    
    
    private JPanel pnlFrame;
    private JPanel pnlVeg;
    private JPanel pnlFr;
    private JPanel pnlTa;
    private JPanel pnlbtn;
    private JScrollPane spDisplay;
    //private ArrayList<> addi;
    
    public ComboBoc_CheckBox_TextArea_btn() {
            pnlFrame=new JPanel();
            pnlVeg=new JPanel();
            pnlFr=new JPanel();
            pnlTa=new JPanel();
            pnlbtn=new JPanel();
            this.add(pnlFrame);
            pnlFrame.add(pnlFr);
            pnlFrame.add(pnlVeg);
            pnlFrame.add(pnlTa);
            pnlFrame.add(pnlbtn);
            
            lblFruit=new JLabel("Fruit");
            lblVegitable=new JLabel("Vegitables");
            
            String[]Fruit={" ","Apple","Mango","Orange","Banana","Grave"};
            cmbxFruit=new JComboBox<>(Fruit);
            chbxVegitables=new JCheckBox();
            taDisplay=new JTextArea(10,10);
            btnSave=new JButton("SAVE");
            btnDisplay=new JButton("DISPLAY");
            
            pnlFr.add(lblFruit);
            pnlFr.add(cmbxFruit);
            pnlVeg.add(lblVegitable);
            pnlVeg.add(chbxVegitables);
            pnlTa.add(taDisplay);
            pnlbtn.add(btnSave);
            pnlbtn.add(btnDisplay);
            taDisplay.setEditable(false);
            cmbxFruit.setSelectedIndex(0);
          
            spDisplay=new JScrollPane(taDisplay, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            pnlTa.add(spDisplay);
            
            //actionLister
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFruit = (String) cmbxFruit.getSelectedItem();
                ArrayList<String> addi = new ArrayList<>();
                if (!chbxVegitables.isSelected() || selectedFruit.equals(" ")) {
                    taDisplay.setText("SELECT CORRECT ITEMS");
                } else {
                    addi.add(selectedFruit);
                    try (BufferedWriter br = new BufferedWriter(new FileWriter("Data.txt", true))) {
                        for (int i = 0; i < addi.size(); i++) {
                            br.write(addi.get(i));
                            br.newLine();
                        }
                    } catch (IOException ex) {
                        ex.printStackTrace(); // Print the full stack trace
                    }
                }
            }
        });
            
           btnDisplay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (BufferedReader breader = new BufferedReader(new FileReader("Data.txt"))) {
                    taDisplay.setText(""); // Clear previous content
                    String line;
                    while ((line = breader.readLine()) != null) {
                        taDisplay.append(line + "\n"); // Append each line to the JTextArea
                    }
                } catch (IOException ex) {
                    ex.printStackTrace(); // Print the full stack trace
                }
            }
        });
          
             
         
            this.setVisible(true);
            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
            this.setTitle(" ComboBox_CheckBox_TextArea_btn");
            this.setSize(300, 350);
            
    }
    
}
